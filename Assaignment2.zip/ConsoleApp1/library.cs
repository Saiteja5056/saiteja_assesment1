﻿using exam_2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class library
    {
        static void Main()
        {
            logics logic = new logics();
            bool exit = false;

            while (!exit)
            {
                Console.WriteLine("Enter your choice:");
                Console.WriteLine("1. Create book");
                Console.WriteLine("2. Update book details");
                Console.WriteLine("3. Display book by ID");
                Console.WriteLine("4. Display book by name");
                Console.WriteLine("5. Display books by author");
                Console.WriteLine("6. Display books by author and publisher");
                Console.WriteLine("7. Display all books");
                Console.WriteLine("8. Exit");
                int op = Convert.ToInt32(Console.ReadLine());

                switch (op)
                {
                    case 1:
                        logic.CreateBook();
                        break;
                    case 2:
                        Console.WriteLine("Enter book id to update:");
                        int id = Convert.ToInt32(Console.ReadLine());
                        logic.UpdateDetails(id);
                        break;
                    case 3:
                        Console.WriteLine("Enter book id:");
                        id = Convert.ToInt32(Console.ReadLine());
                        logic.DisplayBookById(id);
                        break;
                    case 4:
                        Console.WriteLine("Enter book name:");
                        string name = Console.ReadLine();
                        logic.DisplayBookByName(name);
                        break;
                    case 5:
                        Console.WriteLine("Enter book author:");
                        string author = Console.ReadLine();
                        logic.DisplayBookByAuthor(author);
                        break;
                    case 6:
                        Console.WriteLine("Enter book author:");
                        author = Console.ReadLine();
                        Console.WriteLine("Enter book publisher:");
                        string publisher = Console.ReadLine();
                        logic.DisplayBookByAuthorAndPublisher(author, publisher);
                        break;
                    case 7:
                        logic.DisplayAllBooks();
                        break;
                    case 8:
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
        }
    }
}
