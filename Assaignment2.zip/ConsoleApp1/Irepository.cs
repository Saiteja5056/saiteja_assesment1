﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal interface Irepository
    {
        void CreateBook();
        void UpdateDetails(int id);
        void DisplayBookById(int id);
        void DisplayBookByName(string name);
        void DisplayBookByAuthor(string author);
        void DisplayBookByAuthorAndPublisher(string author, string publisher);
        void DisplayAllBooks();
    }
}
