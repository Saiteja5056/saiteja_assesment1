﻿using ConsoleApp1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Reflection.Metadata.BlobBuilder;

namespace exam_2
{
    class logics : Irepository
    {
        List<Book> books = new List<Book>();

        public void CreateBook()
        {
            Console.WriteLine("Enter book name:");
            string name = Console.ReadLine();
            Console.WriteLine("Enter book id:");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter book price:");
            int price = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter book author:");
            string author = Console.ReadLine();
            Console.WriteLine("Enter book publisher:");
            string publisher = Console.ReadLine();
            books.Add(new Book { BookId = id, BookName = name, Price = price, Author = author, Publisher = publisher });
            Console.WriteLine("Book created successfully.");
        }

        public void DisplayAllBooks()
        {
            if (books.Count == 0)
            {
                Console.WriteLine("No books available.");
                return;
            }

            foreach (Book b in books)
            {
                Console.WriteLine(b.ToString());
            }
        }

        public void DisplayBookByAuthor(string author)
        {
            var res = books.Where(b => b.Author.Equals(author, StringComparison.OrdinalIgnoreCase)).ToList();
            if (res.Count > 0)
            {
                foreach (Book b in res)
                {
                    Console.WriteLine(b.ToString());
                }
            }
            else
            {
                Console.WriteLine("No books found by that author.");
            }
        }

        public void DisplayBookByAuthorAndPublisher(string author, string publisher)
        {
            var res = books.Where(b => b.Author.Equals(author, StringComparison.OrdinalIgnoreCase) &&
                                       b.Publisher.Equals(publisher, StringComparison.OrdinalIgnoreCase)).ToList();
            if (res.Count > 0)
            {
                foreach (Book b in res)
                {
                    Console.WriteLine(b.ToString());
                }
            }
            else
            {
                Console.WriteLine("No books found by that author and publisher.");
            }
        }

        public void DisplayBookById(int id)
        {
            var book = books.FirstOrDefault(b => b.BookId == id);
            if (book != null)
            {
                Console.WriteLine(book.ToString());
            }
            else
            {
                Console.WriteLine("Book not found.");
            }
        }

        public void DisplayBookByName(string name)
        {
            var res = books.Where(b => b.BookName.Equals(name, StringComparison.OrdinalIgnoreCase)).ToList();
            if (res.Count > 0)
            {
                foreach (Book b in res)
                {
                    Console.WriteLine(b.ToString());
                }
            }
            else
            {
                Console.WriteLine("No books found with that name.");
            }
        }

        public void UpdateDetails(int id)
        {
            var book = books.FirstOrDefault(b => b.BookId == id);
            if (book != null)
            {
                Console.WriteLine("Enter new book name (leave blank to keep current):");
                string name = Console.ReadLine();
                if (!string.IsNullOrWhiteSpace(name))
                    book.BookName = name;

                Console.WriteLine("Enter new price (leave blank to keep current):");
                string priceInput = Console.ReadLine();
                if (!string.IsNullOrWhiteSpace(priceInput))
                    book.Price = Convert.ToInt32(priceInput);

                Console.WriteLine("Enter new author (leave blank to keep current):");
                string author = Console.ReadLine();
                if (!string.IsNullOrWhiteSpace(author))
                    book.Author = author;

                Console.WriteLine("Enter new publisher (leave blank to keep current):");
                string publisher = Console.ReadLine();
                if (!string.IsNullOrWhiteSpace(publisher))
                    book.Publisher = publisher;

                Console.WriteLine("Book updated successfully.");
            }
            else
            {
                Console.WriteLine("Book not found.");
            }
        }
    }

}
